import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class HideCard here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HideCard extends Actor
{
    public String Hiding;
    /**
     * Act - do whatever the HideCard wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
    public HideCard(){
        
        String a ="backCard.png";
 
        GreenfootImage img = new GreenfootImage(a);
        img.scale(70,70);
        setImage(img);
        this.Hiding = Hiding;
    }
}
