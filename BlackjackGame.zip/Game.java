import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
import java.util.ArrayList;
/**
 * Write a description of class game here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Game extends Actor
{
    /**
     * Act - do whatever the game wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private int x;
    private int y;
    private int z;
    private int w;
    private int i;
    private int j;
    private int k;
    private int l;
    private int total;
    private int total2;
    
    public void setUpGame()
    {
        rule(); //add the image of rule: ace of diamond = 11, ace of club = 1
        opponent(); //display an image of opponent
        Player(); //display an imagee of player
        this.i = getNum();
        card(i); //player's first card
        this.j = getNum();
        card2(j); //player's second card
        this.total2 = this.i+ this.j;
        Number();//compute CPU's cards
        cardOp(x); //CPU's first card
        cardOp2(y);//CPU's second card
        HideCardY();//hiding CPU's second card
        if(x+y < 21){
            cardOp3(z);//CPU's third card
            HideCardZ();//hiding CPU's third card
            if (x+y+z <21) {
                cardOp4(w);//CPU's fourth card
                HideCardW();//hiding CPU's fourth card
            }
        }
       
    }
    public void act(){
        String x = Greenfoot.getKey();
        addText("Do you want to draw another card? Click right for yes, left for no");
        if ("right".equals(x)){ 
            if (k == 0){
                deleteText("Do you want to draw another card? Click right for yes, left for no");
                k = getNum();
                card3(k); //player's third card
                this.total2 += this.k;
            }
            
            else if(k!=0 ){
                deleteText("Do you want to draw another card? Click right for yes, left for no");
                l = getNum();
                card4(l); //player's fourth card
                this.total2 += this.l;
                if(l!=0){
                    finishGame();
                }
            }  
        }
        if ("left".equals(x)){
            deleteText("Do you want to draw another card? Click right for yes, left for no");
            finishGame();
        }
    }
    
    public void finishGame() {
        String result = ""; 
        HideCardRemove(); //remove the green cover of CPU's cards
        if(total>21 && total2 > 21){
            result = "The game is tied";
            addText(result);
        }
        if(total>21 && total2 <= 21){
            result = "You won the game!";
            addText(result);
        }
        if(total == total2){
            result = "The game is tied";
            addText(result);
        }
        if(total2<=21 && total>21){
            result = "You won the game!";
            addText(result);
        }
        if(total <=21 && total2 > 21){
            result = "You lost the game";
            addText(result);
        }
        if(total<=21 && total2<=21 && total2>total){
            result = "You won the game!";
            addText(result);
        }
        if(total<=21 && total2<=21 && total2<total){
            result = "You lost the game";
            addText(result);
        }
        Greenfoot.stop();
    }
    
    public void rule() {
        Actor rule = new Rule();
        World world = getWorld();
        
        world.addObject(rule,270,380);
    }
    public void Player() {
        Actor player = new Player();
        World world = getWorld();
        
        world.addObject(player,180,300);
    }
    public void opponent() {
        Actor opponent = new Opponent();
        World world = getWorld();
        
        world.addObject(opponent,180,190);
    }
    public void cardOp(int x){
        Actor card = new Card(x);
        World world = getWorld();
        
        world.addObject(card,250,200);
    }
    public void cardOp2(int x){
        Actor card = new Card(x);
        World world = getWorld();
        
        world.addObject(card,300,200);
    }
    public void cardOp3(int x){
        Actor card = new Card(x);
        World world = getWorld();
        
        world.addObject(card,350,200);
    }
    public void cardOp4(int x){
        Actor card = new Card(x);
        World world = getWorld();
        
        world.addObject(card,400,200);
    }
    public void card(int x){
        Actor card = new Card(x);
        World world = getWorld();
        
        world.addObject(card,250,300);
    }
    
    public void card2(int x){
        Actor card = new Card(x);
        World world = getWorld();
        
        world.addObject(card,300,300);
    }
    
    public void card3(int x){
        Actor card = new Card(x);
        World world = getWorld();
        
        world.addObject(card,350,300);
    }
    
    public void card4(int x){
        Actor card = new Card(x);
        World world = getWorld();
        
        world.addObject(card,400,300);
    }
    
    public void HideCard(){
        Actor HideCard = new HideCard();
        World world = getWorld();
        
        world.addObject(HideCard,250,300);
    }
    public void HideCardY(){
        Actor HideCard = new HideCard();
        World world = getWorld();
        
        world.addObject(HideCard,300,200);
    }  
    public void HideCardZ(){
        Actor HideCard = new HideCard();
        World world = getWorld();
        
        world.addObject(HideCard,350,200);
    }  
    public void HideCardW(){
        Actor HideCard = new HideCard();
        World world = getWorld();
        
        world.addObject(HideCard,400,200);
    }  
    public void HideCardRemove(){
        Actor HideCard = new HideCard();
        World world = getWorld();
        world.removeObjects(world.getObjects(HideCard.class));
      
    }  
    public void addText(String text){
        Actor message = new Message(text);
        World world = getWorld();
        
        world.addObject(message,300,100);
    }
    
    public void deleteText(String text){
        Actor message = new Message(text);
        World world = getWorld();
        List<Message> l = world.getObjects(Message.class);
        for(int i =l.size()-1;i>=0;i--){
            if(l.get(i).text.equals(text)){
                world.removeObject(l.get(i));
            }
        }
        
    }
    public void Number(){ 
        total = 0; //CPU
        double a = Math.random()*12+1;
        x = (int)(a);
        if (x >=12){
            x = 10;
        }
        double b = Math.random()*12+1;
        y = (int)(b);
        if (y >=12){
            y = 10;
        }
        double c = Math.random()*12+1;
        z = (int)(c);
        if (z >=12){
            z = 10;
        }
        double d = Math.random()*12+1;
        w = (int)(d);
        if (w >=12){
            w = 10;
        }
        total = x+y;
        if (total<21){
            total += z;
            if(total<21){
                total+= w;   
            }
        }
    }
    public int getNum(){ 
        double a = Math.random()*12+1; //this part accounts for Queen, and King
        int x = (int)(a);
        if (x >=12){ //this code accounts for Queen, and King
            x = 10;
        }
        return x;
    }
    
    
}
      
